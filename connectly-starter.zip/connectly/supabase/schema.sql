-- Connectly starter database schema for Supabase.
-- Run this in Supabase SQL Editor. Do not expose the service_role key in the app.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 30),
  age_band text not null check (age_band in ('13-15','16-17')),
  bio text not null default '' check (char_length(bio) <= 160),
  interests text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists public.communities (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  topic text not null,
  description text not null,
  icon text not null default '🌱',
  created_at timestamptz not null default now()
);


-- Create a profile and free subscription automatically when an Auth account is created.
-- This works even when email confirmation means the new user has no active session yet.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  requested_band text;
begin
  requested_band := coalesce(new.raw_user_meta_data->>'age_band', '13-15');
  if requested_band not in ('13-15','16-17') then
    requested_band := '13-15';
  end if;

  insert into public.profiles (id, display_name, age_band)
  values (
    new.id,
    left(coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'Member'), 30),
    requested_band
  )
  on conflict (id) do nothing;

  insert into public.subscriptions (user_id, plan, status)
  values (new.id, 'free', 'inactive')
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_connectly on auth.users;
create trigger on_auth_user_created_connectly
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.community_members (
  community_id uuid not null references public.communities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (community_id, user_id)
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  community_id uuid not null references public.communities(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.moderators (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
-- Only a trusted project owner using the Supabase SQL editor/service role should add moderators.

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  reason text not null,
  details text not null default '' check (char_length(details) <= 500),
  status text not null default 'open' check (status in ('open','reviewed','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

-- Entitlement records are written only by trusted server-side payment verification later.
create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','premium')),
  status text not null default 'inactive' check (status in ('inactive','active','cancelled','expired')),
  valid_until timestamptz,
  updated_at timestamptz not null default now()
);

create or replace function public.is_moderator()
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.moderators where user_id = auth.uid()); $$;

alter table public.profiles enable row level security;
alter table public.communities enable row level security;
alter table public.community_members enable row level security;
alter table public.posts enable row level security;
alter table public.moderators enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;
alter table public.subscriptions enable row level security;

drop policy if exists "profiles visible to signed-in users" on public.profiles;
create policy "profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "user inserts own profile" on public.profiles;
create policy "user inserts own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "user updates own profile" on public.profiles;
create policy "user updates own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "communities visible to signed-in users" on public.communities;
create policy "communities visible to signed-in users" on public.communities for select to authenticated using (true);
drop policy if exists "moderators manage communities" on public.communities;
create policy "moderators manage communities" on public.communities for all to authenticated using (public.is_moderator()) with check (public.is_moderator());

drop policy if exists "members visible to signed-in users" on public.community_members;
create policy "members visible to signed-in users" on public.community_members for select to authenticated using (true);
drop policy if exists "users join as themselves" on public.community_members;
create policy "users join as themselves" on public.community_members for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "users leave own communities" on public.community_members;
create policy "users leave own communities" on public.community_members for delete to authenticated using (user_id = auth.uid());

drop policy if exists "approved posts visible" on public.posts;
create policy "approved posts visible" on public.posts for select to authenticated using (
  status = 'approved' or author_id = auth.uid() or public.is_moderator()
);
drop policy if exists "members submit pending posts" on public.posts;
create policy "members submit pending posts" on public.posts for insert to authenticated with check (
  author_id = auth.uid() and status = 'pending'
  and exists(select 1 from public.community_members m where m.community_id = posts.community_id and m.user_id = auth.uid())
);
drop policy if exists "moderators review posts" on public.posts;
create policy "moderators review posts" on public.posts for update to authenticated using (public.is_moderator()) with check (public.is_moderator());
drop policy if exists "authors delete own pending posts" on public.posts;
create policy "authors delete own pending posts" on public.posts for delete to authenticated using (author_id = auth.uid() and status = 'pending');

drop policy if exists "moderators view moderator list" on public.moderators;
create policy "moderators view moderator list" on public.moderators for select to authenticated using (public.is_moderator());

drop policy if exists "users create reports" on public.reports;
create policy "users create reports" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
drop policy if exists "moderators review reports" on public.reports;
create policy "moderators review reports" on public.reports for select to authenticated using (public.is_moderator());
drop policy if exists "moderators update reports" on public.reports;
create policy "moderators update reports" on public.reports for update to authenticated using (public.is_moderator()) with check (public.is_moderator());

drop policy if exists "users manage own blocks" on public.blocks;
create policy "users manage own blocks" on public.blocks for all to authenticated using (blocker_id = auth.uid()) with check (blocker_id = auth.uid());

drop policy if exists "users view own subscription" on public.subscriptions;
create policy "users view own subscription" on public.subscriptions for select to authenticated using (user_id = auth.uid());
-- No client insert/update/delete policy for subscriptions: trusted server-side code only.

insert into public.communities (name, topic, description, icon)
select v.name, v.topic, v.description, v.icon
from (values
 ('Study Corner','Learning','Share study tips, revision goals and helpful resources.','📚'),
 ('Football Fans','Sports','Talk tactics, teams and the beautiful game respectfully.','⚽'),
 ('Art & Creativity','Creative','Share ideas, drawing prompts and creative projects.','🎨'),
 ('Young Tech Makers','Technology','Learn coding, robotics and responsible technology.','💻')
) as v(name,topic,description,icon)
where not exists (select 1 from public.communities c where c.name = v.name);
