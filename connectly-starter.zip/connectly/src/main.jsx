import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Home, Users, UserRound, ShieldCheck, Crown, LogOut, Plus, Flag,
  Ban, MessageCircle, Heart, Sparkles, Menu, X, LockKeyhole, Send
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from './supabase';
import './style.css';

const seedGroups = [
  { id: 'demo-study', name: 'Study Corner', topic: 'Learning', description: 'Share study tips, revision goals and helpful resources.', members: 128, icon: '📚' },
  { id: 'demo-football', name: 'Football Fans', topic: 'Sports', description: 'Talk tactics, teams and the beautiful game respectfully.', members: 214, icon: '⚽' },
  { id: 'demo-art', name: 'Art & Creativity', topic: 'Creative', description: 'Share ideas, drawing prompts and creative projects.', members: 96, icon: '🎨' },
  { id: 'demo-tech', name: 'Young Tech Makers', topic: 'Technology', description: 'Learn coding, robotics and responsible technology.', members: 173, icon: '💻' }
];

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [page, setPage] = useState('home');
  const [groups, setGroups] = useState(seedGroups);
  const [posts, setPosts] = useState([]);
  const [activeGroup, setActiveGroup] = useState(null);
  const [loading, setLoading] = useState(isSupabaseConfigured);
  const [notice, setNotice] = useState('');
  const [authMode, setAuthMode] = useState('signup');
  const [authForm, setAuthForm] = useState({ email: '', password: '', displayName: '', ageBand: '13-15', accepted: false });
  const [newPost, setNewPost] = useState('');
  const [reportTarget, setReportTarget] = useState(null);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user) { setProfile(null); return; }
    loadProfile();
    loadGroups();
  }, [session]);

  useEffect(() => {
    if (activeGroup && session) loadPosts(activeGroup.id);
  }, [activeGroup, session]);

  async function loadProfile() {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', session.user.id).maybeSingle();
    if (error) setNotice(error.message);
    setProfile(data);
  }

  async function loadGroups() {
    const { data, error } = await supabase.from('communities').select('*').order('name');
    if (!error && data?.length) setGroups(data);
  }

  async function loadPosts(groupId) {
    const { data: blockedRows } = await supabase.from('blocks').select('blocked_id').eq('blocker_id', session.user.id);
    const blockedIds = (blockedRows || []).map(row => row.blocked_id);
    const { data, error } = await supabase.from('posts').select('id, body, created_at, author_id, profiles(display_name)').eq('community_id', groupId).eq('status', 'approved').order('created_at', { ascending: false }).limit(60);
    if (error) setNotice(error.message);
    else setPosts((data || []).filter(post => !blockedIds.includes(post.author_id)));
  }

  async function handleAuth(e) {
    e.preventDefault();
    setNotice('');
    if (!isSupabaseConfigured) return setNotice('Connect Supabase first using the setup guide. Demo preview is available below.');
    if (authMode === 'signup') {
      if (!authForm.accepted) return setNotice('Please confirm that you agree to the community safety rules.');
      const { data, error } = await supabase.auth.signUp({
        email: authForm.email.trim(),
        password: authForm.password,
        options: { data: { display_name: authForm.displayName.trim(), age_band: authForm.ageBand } }
      });
      if (error) return setNotice(error.message);
      if (data.user) {
        // A database trigger creates the profile securely, including when email confirmation is enabled.
        setNotice('Account created. Check your email if confirmation is enabled.');
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({
        email: authForm.email.trim(), password: authForm.password
      });
      if (error) setNotice(error.message);
    }
  }

  async function saveProfile(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const updates = {
      display_name: String(form.get('display_name') || '').trim(),
      bio: String(form.get('bio') || '').trim().slice(0, 160),
      interests: String(form.get('interests') || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 8)
    };
    const { error } = await supabase.from('profiles').update(updates).eq('id', session.user.id);
    setNotice(error ? error.message : 'Profile updated.');
    if (!error) loadProfile();
  }

  async function joinGroup(group) {
    if (!session) return;
    const { error } = await supabase.from('community_members').upsert(
      { community_id: group.id, user_id: session.user.id },
      { onConflict: 'community_id,user_id' }
    );
    setNotice(error ? error.message : `Joined ${group.name}.`);
  }

  async function submitPost(e) {
    e.preventDefault();
    if (!newPost.trim() || !activeGroup) return;
    const { error } = await supabase.from('posts').insert({
      community_id: activeGroup.id, author_id: session.user.id,
      body: newPost.trim().slice(0, 1000), status: 'pending'
    });
    setNotice(error ? error.message : 'Your post was submitted for moderator review before it appears.');
    setNewPost('');
  }

  async function submitReport(e) {
    e.preventDefault();
    if (!reportTarget) return;
    const form = new FormData(e.currentTarget);
    const { error } = await supabase.from('reports').insert({
      reporter_id: session.user.id,
      post_id: reportTarget.id,
      reason: String(form.get('reason') || 'Other'),
      details: String(form.get('details') || '').slice(0, 500)
    });
    setNotice(error ? error.message : 'Report sent to the moderation team.');
    setReportTarget(null);
  }

  async function blockAuthor(authorId) {
    if (!authorId || authorId === session.user.id) return;
    const { error } = await supabase.from('blocks').upsert(
      { blocker_id: session.user.id, blocked_id: authorId },
      { onConflict: 'blocker_id,blocked_id' }
    );
    setNotice(error ? error.message : 'User blocked. Their posts are now hidden from your discussion view.');
    if (!error && activeGroup) loadPosts(activeGroup.id);
  }

  async function logout() {
    if (supabase) await supabase.auth.signOut();
    setSession(null); setPage('home'); setActiveGroup(null);
  }

  const navItems = [
    ['home', 'Home', Home], ['communities', 'Communities', Users],
    ['profile', 'My profile', UserRound], ['safety', 'Safety centre', ShieldCheck],
    ['premium', 'Premium', Crown]
  ];

  if (loading) return <div className="loading-screen"><div className="brand-mark">C</div><p>Loading Connectly…</p></div>;

  if (!session) return <AuthScreen
    authMode={authMode} setAuthMode={setAuthMode} authForm={authForm}
    setAuthForm={setAuthForm} handleAuth={handleAuth} notice={notice}
    configured={isSupabaseConfigured}
  />;

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'show' : ''}`}>
        <div className="brand"><div className="brand-mark">C</div><span>connectly</span><button className="icon-button close-nav" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
        <div className="nav-label">WORKSPACE</div>
        {navItems.map(([id, label, Icon]) => <button key={id} className={`nav-item ${page === id ? 'selected' : ''}`} onClick={() => {setPage(id); setActiveGroup(null); setMobileNav(false);}}><Icon size={18}/><span>{label}</span></button>)}
        <div className="sidebar-bottom"><div className="safety-note"><ShieldCheck size={18}/><div><b>Safety first</b><small>Be kind. Keep private details private.</small></div></div><button className="nav-item" onClick={logout}><LogOut size={18}/><span>Sign out</span></button></div>
      </aside>

      <main className="main-area">
        <header className="topbar"><button className="icon-button menu-button" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumb">Connectly <span>/</span> {activeGroup ? activeGroup.name : navItems.find(n => n[0] === page)?.[1]}</div><div className="top-user"><div className="avatar">{(profile?.display_name || 'U').slice(0,1).toUpperCase()}</div><span>{profile?.display_name || 'Member'}</span></div></header>
        <div className="content">
          {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice('')}><X size={15}/></button></div>}
          {activeGroup ? <GroupView group={activeGroup} posts={posts} newPost={newPost} setNewPost={setNewPost} submitPost={submitPost} setReportTarget={setReportTarget} blockAuthor={blockAuthor} onBack={() => setActiveGroup(null)} /> : null}
          {!activeGroup && page === 'home' && <HomePage profile={profile} groups={groups} openGroup={setActiveGroup} go={setPage}/>}
          {!activeGroup && page === 'communities' && <CommunitiesPage groups={groups} openGroup={setActiveGroup} joinGroup={joinGroup}/>}
          {!activeGroup && page === 'profile' && <ProfilePage profile={profile} saveProfile={saveProfile}/>}
          {!activeGroup && page === 'safety' && <SafetyPage/>}
          {!activeGroup && page === 'premium' && <PremiumPage/>}
        </div>
      </main>
      {reportTarget && <div className="modal-backdrop"><form className="modal" onSubmit={submitReport}><div className="modal-head"><h3>Report content</h3><button type="button" className="icon-button" onClick={() => setReportTarget(null)}><X/></button></div><p className="muted">Tell moderators what concerns you. Reports are private.</p><label>Reason<select name="reason"><option>Bullying or harassment</option><option>Spam or scam</option><option>Personal information</option><option>Unsafe or inappropriate content</option><option>Other</option></select></label><label>More details<textarea name="details" rows="3" maxLength="500" placeholder="Optional details…"/></label><button className="primary full" type="submit">Send report</button></form></div>}
    </div>
  );
}

function AuthScreen({ authMode, setAuthMode, authForm, setAuthForm, handleAuth, notice, configured }) {
  const set = (key, value) => setAuthForm(prev => ({...prev, [key]: value}));
  return <div className="auth-layout">
    <div className="auth-visual"><div className="brand"><div className="brand-mark">C</div><span>connectly</span></div><div className="visual-copy"><span className="eyebrow">YOUR INTERESTS. YOUR COMMUNITY.</span><h1>Find your people.<br/><em>Grow together.</em></h1><p>A welcoming space for shared interests, learning and positive conversations.</p><div className="bubble-row"><span>📚 Study</span><span>⚽ Sports</span><span>🎨 Creativity</span><span>💻 Tech</span></div></div><div className="visual-foot">Community guidelines • Moderated spaces • Privacy matters</div></div>
    <div className="auth-panel"><div className="auth-card"><div className="mobile-brand brand"><div className="brand-mark">C</div><span>connectly</span></div><span className="eyebrow">{authMode === 'signup' ? 'GET STARTED' : 'WELCOME BACK'}</span><h2>{authMode === 'signup' ? 'Create your account' : 'Sign in'}</h2><p className="muted">A safer place to connect around what you enjoy.</p>
      {!configured && <div className="setup-warning"><LockKeyhole size={17}/><span>Backend not connected yet. Follow README.md to connect Supabase before real accounts can be created.</span></div>}
      <form onSubmit={handleAuth}>
        {authMode === 'signup' && <><label>Display name<input required maxLength="30" value={authForm.displayName} onChange={e => set('displayName', e.target.value)} placeholder="What should the community call you?"/></label><label>Age group<select value={authForm.ageBand} onChange={e => set('ageBand', e.target.value)}><option value="13-15">13–15</option><option value="16-17">16–17</option></select></label></>}
        <label>Email address<input type="email" required autoComplete="email" value={authForm.email} onChange={e => set('email', e.target.value)} placeholder="you@example.com"/></label>
        <label>Password<input type="password" required minLength="8" autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'} value={authForm.password} onChange={e => set('password', e.target.value)} placeholder="At least 8 characters"/></label>
        {authMode === 'signup' && <label className="checkline"><input type="checkbox" checked={authForm.accepted} onChange={e => set('accepted', e.target.checked)}/><span>I agree to the community rules and understand that posts are reviewed by moderators.</span></label>}
        <button className="primary full" type="submit">{authMode === 'signup' ? 'Create account' : 'Sign in'}</button>
      </form>
      {notice && <div className="inline-notice">{notice}</div>}
      <p className="switch-auth">{authMode === 'signup' ? 'Already have an account?' : 'New to Connectly?'} <button onClick={() => setAuthMode(authMode === 'signup' ? 'login' : 'signup')}>{authMode === 'signup' ? 'Sign in' : 'Create account'}</button></p>
      <p className="legal-note">Connectly is designed for ages 13–17. No dating, private direct messages or public location sharing.</p>
    </div></div>
  </div>;
}

function HomePage({ profile, groups, openGroup, go }) {
  return <><div className="welcome-row"><div><span className="eyebrow">YOUR COMMUNITY SPACE</span><h1>Good to see you, {profile?.display_name || 'there'}.</h1><p className="muted">Explore your interests and join positive conversations.</p></div><div className="welcome-art">✦</div></div>
    <div className="stats-grid"><div className="stat-card"><div className="stat-icon purple"><Users/></div><div><b>{groups.length}</b><small>Interest communities</small></div></div><div className="stat-card"><div className="stat-icon green"><ShieldCheck/></div><div><b>Moderated</b><small>Posts reviewed before publishing</small></div></div><div className="stat-card"><div className="stat-icon orange"><Heart/></div><div><b>Respect</b><small>Kindness is the culture</small></div></div></div>
    <div className="section-heading"><div><h2>Explore communities</h2><p className="muted">Find a group around something you enjoy.</p></div><button className="text-button" onClick={() => go('communities')}>View all <span>→</span></button></div>
    <div className="community-grid">{groups.slice(0,3).map(g => <CommunityCard key={g.id} group={g} open={() => openGroup(g)}/>)}</div>
    <div className="tip-banner"><div className="tip-icon"><Sparkles/></div><div><b>A quick privacy reminder</b><p>Keep your phone number, home address, school details and passwords private. A real friend will respect that.</p></div></div>
  </>;
}

function CommunityCard({ group, open }) {
  return <button className="community-card" onClick={open}><div className="community-card-top"><span className="community-emoji">{group.icon || '🌱'}</span><span className="tag">{group.topic || 'Community'}</span></div><h3>{group.name}</h3><p>{group.description}</p><div className="card-foot"><span><Users size={14}/> {group.members || 0} members</span><span className="arrow">↗</span></div></button>;
}

function CommunitiesPage({ groups, openGroup, joinGroup }) {
  return <><div className="page-heading"><span className="eyebrow">DISCOVER</span><h1>Communities</h1><p className="muted">Join interest-based spaces. Keep conversations respectful and on topic.</p></div><div className="community-grid">{groups.map(g => <div className="community-wrap" key={g.id}><CommunityCard group={g} open={() => openGroup(g)}/><button className="join-link" onClick={() => joinGroup(g)}>Join community <span>→</span></button></div>)}</div></>;
}

function GroupView({ group, posts, newPost, setNewPost, submitPost, setReportTarget, blockAuthor, onBack }) {
  return <><button className="back-link" onClick={onBack}>← All communities</button><div className="group-hero"><span className="community-emoji large">{group.icon || '🌱'}</span><div><span className="tag">{group.topic || 'Community'}</span><h1>{group.name}</h1><p className="muted">{group.description}</p></div></div>
    <div className="moderation-banner"><ShieldCheck size={18}/> New posts are checked by moderators before appearing to everyone. No private messaging in Connectly.</div>
    <div className="discussion-layout"><section className="discussion-main"><div className="section-heading"><h2>Community discussion</h2><span className="muted small">Approved posts</span></div>
      {posts.length === 0 ? <div className="empty-state"><MessageCircle size={30}/><b>Start a positive conversation</b><p>There are no approved posts here yet.</p></div> : posts.map(p => <article className="post-card" key={p.id}><div className="post-author"><div className="avatar small-avatar">{(p.profiles?.display_name || 'M').slice(0,1).toUpperCase()}</div><div><b>{p.profiles?.display_name || 'Community member'}</b><small>{new Date(p.created_at).toLocaleString()}</small></div><div className="post-actions"><button title="Report post" onClick={() => setReportTarget(p)}><Flag size={16}/></button><button title="Block author" onClick={() => blockAuthor(p.author_id)}><Ban size={16}/></button></div></div><p className="post-body">{p.body}</p></article>)}
      <form className="compose-card" onSubmit={submitPost}><label htmlFor="post">Share something helpful or start a discussion</label><textarea id="post" rows="3" maxLength="1000" value={newPost} onChange={e => setNewPost(e.target.value)} placeholder="Write a respectful community post…"/><div className="compose-foot"><small>{newPost.length}/1000 • Reviewed before publishing</small><button className="primary" type="submit" disabled={!newPost.trim()}><Send size={15}/> Submit for review</button></div></form>
    </section><aside className="group-sidebar"><div className="side-card"><h3>Community guidelines</h3><ul><li>Be respectful and inclusive.</li><li>Do not share personal contact details.</li><li>No bullying, threats or harassment.</li><li>Keep posts relevant to the group.</li><li>Report anything that feels unsafe.</li></ul></div></aside></div>
  </>;
}

function ProfilePage({ profile, saveProfile }) {
  return <><div className="page-heading"><span className="eyebrow">YOUR SPACE</span><h1>My profile</h1><p className="muted">Share interests, not private information.</p></div><form className="profile-form panel" onSubmit={saveProfile}><div className="profile-header"><div className="profile-avatar">{(profile?.display_name || 'U').slice(0,1).toUpperCase()}</div><div><h2>{profile?.display_name || 'Your profile'}</h2><span className="tag">Age group: {profile?.age_band || 'Not set'}</span></div></div><label>Display name<input name="display_name" required maxLength="30" defaultValue={profile?.display_name || ''}/></label><label>Short bio<textarea name="bio" rows="3" maxLength="160" defaultValue={profile?.bio || ''} placeholder="A little about your interests…"/></label><label>Interests <small className="muted">(separate with commas)</small><input name="interests" defaultValue={(profile?.interests || []).join(', ')} placeholder="Football, coding, music"/></label><div className="privacy-callout"><LockKeyhole size={17}/> Do not include your full name, phone number, school, home address or live location.</div><button className="primary" type="submit">Save profile</button></form></>;
}

function SafetyPage() {
  return <><div className="page-heading"><span className="eyebrow">LOOKING OUT FOR EACH OTHER</span><h1>Safety centre</h1><p className="muted">Your safety matters more than engagement or popularity.</p></div><div className="safety-grid"><div className="safety-card"><ShieldCheck/><h3>Moderated discussions</h3><p>New posts stay pending until a moderator reviews them. This starter project does not include private direct messages.</p></div><div className="safety-card"><Flag/><h3>Report content</h3><p>Use the report control on a post to flag bullying, spam, personal information or unsafe content.</p></div><div className="safety-card"><Ban/><h3>Block accounts</h3><p>Block an account if you do not want to interact with it. Tell a trusted adult if someone makes you feel unsafe.</p></div><div className="safety-card"><LockKeyhole/><h3>Protect your details</h3><p>Never post passwords, phone numbers, home addresses, school details or private documents.</p></div></div><div className="tip-banner"><div className="tip-icon"><ShieldCheck/></div><div><b>Need help?</b><p>If there is an immediate safety concern, stop interacting and contact a trusted adult or appropriate local support service.</p></div></div></>;
}

function PremiumPage() {
  return <><div className="premium-hero"><div className="premium-symbol"><Crown size={30}/></div><span className="eyebrow">OPTIONAL EXTRAS</span><h1>Connectly Premium</h1><p>Extra ways to personalise your community experience. Core community and safety features stay free.</p><div className="price-line"><strong>KSh 150</strong><span>/ month — proposed price, not yet active</span></div><span className="coming-soon">PAYMENTS NOT ENABLED</span></div><div className="premium-grid"><div className="premium-item"><Sparkles/><b>Extra themes</b><p>More colour and appearance choices.</p></div><div className="premium-item"><UserRound/><b>Profile customisation</b><p>Additional profile style options.</p></div><div className="premium-item"><Users/><b>Community extras</b><p>Optional tools for organising group spaces.</p></div></div><div className="payment-note"><LockKeyhole/><div><b>Why can't I subscribe yet?</b><p>Real payments are deliberately disabled. Before launch, an appropriate adult/business owner must set up the merchant and developer accounts, verify the payment integration, obtain any required approvals, and follow Google Play's rules for digital subscriptions. Never share an M-PESA PIN or payment password with this app.</p></div></div></>;
}

createRoot(document.getElementById('root')).render(<App />);
